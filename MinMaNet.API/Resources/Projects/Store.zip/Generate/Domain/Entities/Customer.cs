using System;

namespace Store.Entities
{
public class Customer 
{
public string Name { get; set; }
public string Email { get; set; }
public DateTime Birth { get; set; }
}
}
